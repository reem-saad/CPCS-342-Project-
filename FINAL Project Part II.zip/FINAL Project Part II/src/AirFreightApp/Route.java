package AirFreightApp;

import GraphFramework.Edge;

/**
 * Represents a route between two locations, equivalent of an edge with modified displayInfo() method.
 */
public class Route extends Edge {

    public Route() {
        // Default Constructor
    }

    @Override
    public void displayInfo() {
        System.out.println(" | route length: " + getWeight());
    }
}
