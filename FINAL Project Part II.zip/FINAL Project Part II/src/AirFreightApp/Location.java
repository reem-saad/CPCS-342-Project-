package AirFreightApp;

import GraphFramework.Vertex;

/**
 * Represents a location, equivalent of a vertex with the option to give the
 * office a name.
 */
public class Location extends Vertex implements Comparable<Location> {

    private static int id = 1;

    public Location() {
        // Default constructor
    }

    @Override
    public int compareTo(Location o) {
        return 0;
    }

    @Override
    public void setLabel() {
        setLabel("Loc" + id++);
    }

    @Override
    public void displayInfo() {
        System.out.print("Loc No. " + getLabel());
    }
}
