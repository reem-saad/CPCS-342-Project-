package AirFreightApp;

import GraphFramework.DBAllSourceSPAlg;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

/**
 * Entry point of the program.
 */
public class AirFreightApp {
    
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        AFRouteMap map = new AFRouteMap();
        
        DBAllSourceSPAlg DB = new DBAllSourceSPAlg(map);
        
        // Reads graph from text file
        List<String> file = Files.readAllLines(Paths.get("GraphPart2.txt"));
        map.readGraphFromFile(file);
       
        DB.computeDijkstraBasedSPAlg();
        
        System.out.println("-------------------------------------------------------------------------------------------");
        System.out.println(">> Test  cases: (where n is the number of vertices and m is the number of edges): ");
        System.out.println(" 1:  n = 2,000,  m = 10,000");
        System.out.println(" 2:  n = 3,000,  m = 15,000");
        System.out.println(" 3:  n = 4,000,  m = 20,000");
        System.out.println(" 4:  n = 5,000,  m = 25,000");
        System.out.println(" 5:  n = 6,000,  m = 30,000");
        System.out.print("\n>> Choose a test case: ");

        switch (input.nextInt()) {
            case 1:
                createGraph(2000, 10000);
                break;
            case 2:
                createGraph(3000, 15000);
                break;
            case 3:
                createGraph(4000, 20000);
                break;
            case 4:
                createGraph(5000, 25000);
                break;
            case 5:
                createGraph(6000, 30000);
                break;
                
            default:
                System.out.println("Invalid input!");
        }
    }

    public static void createGraph(int vertices, int edges) {
        AFRouteMap graph = new AFRouteMap(vertices, edges);
        
        DBAllSourceSPAlg DB = new DBAllSourceSPAlg(graph);
        
        System.out.print("\n>> Is the graph directed?\n   Enter (true) or (false): ");
        String directed = input.next();

        graph.isDigraph = directed.equalsIgnoreCase("true");
    
        graph.make_graph();
        
        DB.computeDijkstraBasedSPAlg();
    }
}
