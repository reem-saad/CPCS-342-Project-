package AirFreightApp;

import GraphFramework.Graph;
import GraphFramework.Vertex;
import GraphFramework.Edge;

public class AFRouteMap extends Graph {

    public AFRouteMap() {
        super();
    }

    public AFRouteMap(int verticesNo, int edgeNo) {
        super(verticesNo, edgeNo);
    }

    @Override
    public Vertex createVertex() {
        return new Location();
    }
    
    @Override
    public Edge createEdge() {
        return new Route();
    }
}
