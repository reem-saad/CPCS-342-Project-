package GraphFramework;

import java.util.*;

public class SingleSourceSPAlg extends ShortestPathAlgorithm {

    public SingleSourceSPAlg(Graph graph) {
        super(graph);
    }

    public void computePath(Vertex sourceVertex) {
        sourceVertex.setMinDistance(0);
        
        PriorityQueue<Vertex> pq = new PriorityQueue<>();
        pq.add(sourceVertex);

        while (!pq.isEmpty()) {
            Vertex vertex = pq.poll();

            // All edges of the current Vertex
            for (Edge edge : vertex.getAdjList()) {
                // Target of current edge
                Vertex target = edge.getTarget();

                // Get weight and min distance between current and target vertex
                double weight = edge.getWeight();
                double minDistance = vertex.getMinDistance() + weight;

                // If current min distance is smaller than the previous
                if (minDistance < target.getMinDistance()) {
                    int weightPlaceholder = (int) weight;
                    target.setParent(vertex);
                    target.getRoute().put(vertex.getLabelNumber(), weightPlaceholder);
                    target.setMinDistance(minDistance);
                    pq.add(target);
                }
            }
        }
    }

    public List<Vertex> getShortestPathTo(Vertex targetVertex) {
        List<Vertex> path = new ArrayList<>();

        Vertex current = targetVertex;
        while(current != null) {
            path.add(current);
            current = current.getParent();
        }

        Collections.reverse(path);

        return path;
    }
}
