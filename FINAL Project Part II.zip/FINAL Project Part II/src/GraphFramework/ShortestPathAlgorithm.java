package GraphFramework;

abstract class ShortestPathAlgorithm {
    
    Graph graph;

    public ShortestPathAlgorithm(Graph graph) {
        this.graph = graph;
    }
}
