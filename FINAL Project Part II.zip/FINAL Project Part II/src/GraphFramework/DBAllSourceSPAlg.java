package GraphFramework;

import java.util.LinkedList;
import java.util.List;

public class DBAllSourceSPAlg extends ShortestPathAlgorithm {

    public DBAllSourceSPAlg(Graph graph) {
        super(graph);
    }

    public void computeDijkstraBasedSPAlg() {
        long startTime = System.currentTimeMillis();

        SingleSourceSPAlg SS = new SingleSourceSPAlg(graph);
        
        boolean print = (graph.vertices.length <= 10);

        // Computes the shortest path to all vertices for every existing vertex in the graph
        for (int i = 0; i < graph.vertices.length; i++) {
            // Computes the shortest path to all other vertices starting from the current vertex
            SS.computePath(graph.vertices[i]);

            //System.out.println(graph.vertices[i].getLabel());
            if (print) {
                // Prints first information
                System.out.println("The starting point is " + graph.vertices[i].getLabel());
                System.out.println("The routes from location " + graph.vertices[i].getLabel() + " to the rest of the locations are:");

                // Iterates over all other vertices
                for (int j = 0; j < graph.vertices.length; j++) {
                    int cost;
                    int totalCost = 0;
                    
                    // If the current vertex from outer loop is not the vertex from inner loop
                    if (i != j) {
                        // Retrieves a list of vertices representing the shortest path
                        List<Vertex> vertices = SS.getShortestPathTo(graph.vertices[j]);
                        
                        if (vertices.size() <= 1) {
                            System.out.println(" ! No route exists from location '" + graph.vertices[i].getLabel()
                                             + "' to location '" + graph.vertices[j].getLabel() + "'");
                            continue;
                        }

                        System.out.print(" * ");
                        for (int k = 0; k < vertices.size(); k++) {
                            vertices.get(k).displayInfo();
                            System.out.print(" -");

                            if (k != vertices.size() - 1) {
                                cost = vertices.get(k + 1).getRoute().get(vertices.get(k).getLabelNumber());
                                System.out.print(cost + "-> ");

                                totalCost += cost;
                            } else {
                                System.out.println("\b\b | Route length: " + totalCost);
                            }
                        }
                    }
                }
            }

            resetGraph(graph);
            if(print)
                System.out.println();
        }

        long endTime = System.currentTimeMillis();

        System.out.println("Total runtime of Djikstra's Algorithm: " + (endTime - startTime) + " ms.");
    }

    /**
     * Resets all vertices in the graph, so that the next calculation of the
     * shortest paths works fine
     *
     * @param graph contains the current graph
     *
     */
    private void resetGraph(Graph graph) {
        for (int i = 0; i < graph.vertices.length; i++) {
            graph.vertices[i].setMinDistance(Double.POSITIVE_INFINITY);
            graph.vertices[i].setIsVisited(false);
            graph.vertices[i].setParent(null);
        }
    }
}
