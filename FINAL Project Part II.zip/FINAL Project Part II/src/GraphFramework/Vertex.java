package GraphFramework;

import java.util.HashMap;
import java.util.LinkedList;

public class Vertex {

    private String label;
    
    int labelNumber;
    
    boolean isVisited;
    
    Vertex parent;
    
    LinkedList<Edge> adjList;
    
    HashMap<Integer, Integer> route = new HashMap<>();
    
    double minDistance = Double.POSITIVE_INFINITY;
    
    // No constructor to ensure no Vertex object has been created

    public void displayInfo() {
        System.out.println(label);
    }
    
   //-------------------------- Getters and Setters --------------------------//
    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
    
    public void setLabel() {
    }

    public int getLabelNumber() {
        return labelNumber;
    }

    public void setLabelNumber(int labelNumber) {
        this.labelNumber = labelNumber;
    }

    public boolean isIsVisited() {
        return isVisited;
    }

    public void setIsVisited(boolean isVisited) {
        this.isVisited = isVisited;
    }

    public LinkedList<Edge> getAdjList() {
        return adjList;
    }

    public void setAdjList(LinkedList<Edge> adjList) {
        this.adjList = adjList;
    }

    public void addAdjList(Edge addition) {
        this.adjList.add(addition);
    }

    public Vertex getParent() {
        return parent;
    }

    public void setParent(Vertex parent) {
        this.parent = parent;
    }

    public double getMinDistance() {
        return minDistance;
    }

    public void setMinDistance(double minDistance) {
        this.minDistance = minDistance;
    }

    public HashMap<Integer, Integer> getRoute() {
        return route;
    }

    public void setRoute(HashMap<Integer, Integer> route) {
        this.route = route;
    }
    
    public void addRoute(int parent, int weight) {
        route.put(parent, weight);
    }
}